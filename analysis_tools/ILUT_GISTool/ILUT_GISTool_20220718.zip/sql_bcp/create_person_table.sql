
CREATE TABLE {} (
	[id] [int] NULL,
	[hhno] [int] NULL,
	[pno] [smallint] NULL,
	[pptyp] [smallint] NULL,
	[pagey] [smallint] NULL,
	[pgend] [smallint] NULL,
	[pwtyp] [smallint] NULL,
	[pwpcl] [int] NULL,
	[pwtaz] [smallint] NULL,
	[pwautime] [real] NULL,
	[pwaudist] [real] NULL,
	[pstyp] [smallint] NULL,
	[pspcl] [int] NULL,
	[pstaz] [smallint] NULL,
	[psautime] [real] NULL,
	[psaudist] [real] NULL,
	[puwmode] [smallint] NULL,
	[puwarrp] [smallint] NULL,
	[puwdepp] [smallint] NULL,
	[ptpass] [smallint] NULL,
	[ppaidprk] [smallint] NULL,
	[pdiary] [smallint] NULL,
	[pproxy] [smallint] NULL,
	[psexpfac] [smallint] NULL
)

