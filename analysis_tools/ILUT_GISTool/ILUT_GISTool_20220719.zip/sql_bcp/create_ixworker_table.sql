

--NOTE: this table in CSV form has no headers on it

CREATE TABLE {} (
	TAZ SMALLINT NULL,
	IXWkrFraxn REAL NULL, --share of workers who live in region and work outside region
	extWkrfraxn REAL NULL, --share of workers who live outside region and work in region
	)
