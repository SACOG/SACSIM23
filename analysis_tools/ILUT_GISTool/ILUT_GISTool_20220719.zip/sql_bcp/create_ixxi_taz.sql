
CREATE TABLE {} (
	[I] [real] NULL,
	[IX_VT_I] [real] NULL,
	[IX_VT_J] [real] NULL,
	[IX_VHT_I] [real] NULL,
	[IX_VHT_J] [real] NULL,
	[IX_VMT_I] [real] NULL,
	[IX_VMT_J] [real] NULL,
	[IX_CVMT_I] [real] NULL,
	[IX_CVMT_J] [real] NULL,
	[HHS] [real] NULL,
	[EMPTOT] [real] NULL,
	[FOOD] [real] NULL,
	[RET] [real] NULL,
	[SVC] [real] NULL
)

