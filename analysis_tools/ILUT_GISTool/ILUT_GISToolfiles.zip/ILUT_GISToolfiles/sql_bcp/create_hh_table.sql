
CREATE TABLE {} (
	[hhno] [int] NULL,
	[fraction_with_jobs_outside] [real] NULL,
	[hhsize] [int] NULL,
	[hhvehs] [int] NULL,
	[hhwkrs] [int] NULL,
	[hhftw] [int] NULL,
	[hhptw] [int] NULL,
	[hhret] [int] NULL,
	[hhoad] [int] NULL,
	[hhuni] [int] NULL,
	[hhhsc] [int] NULL,
	[hh515] [int] NULL,
	[hhcu5] [int] NULL,
	[hhincome] [int] NULL,
	[hownrent] [int] NULL,
	[hrestype] [int] NULL,
	[hhparcel] [int] NULL,
	[zone_id] [int] NULL,
	[hhtaz] [int] NULL,
	[hhexpfac] [int] NULL,
	[samptype] [int] NULL
)
